package com.tejando.keyboard.engine

/**
 * Ponto de extensão das sugestões de palavras.
 *
 * Para evoluir (bigramas, dicionário do usuário, modelo on-device...), crie outra
 * implementação e troque em TejandoKeyboardService.
 */
interface SuggestionEngine {
    /**
     * @param textBeforeCursor texto imediatamente antes do cursor (algumas dezenas de caracteres).
     * @return até [max] sugestões, já prontas pra serem inseridas no lugar da palavra atual.
     */
    fun suggest(textBeforeCursor: String, max: Int = 3): List<String>
}

/** Parte da palavra que está sendo digitada agora (letras logo antes do cursor). */
fun currentWordPrefix(textBeforeCursor: String): String =
    textBeforeCursor.takeLastWhile { it.isLetter() }
