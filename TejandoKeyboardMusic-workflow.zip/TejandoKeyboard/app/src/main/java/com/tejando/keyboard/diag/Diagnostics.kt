package com.tejando.keyboard.diag

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import com.tejando.keyboard.audio.Drum
import com.tejando.keyboard.audio.Instrument
import com.tejando.keyboard.audio.KeyMap
import com.tejando.keyboard.audio.MixerState
import com.tejando.keyboard.audio.MixerStore
import com.tejando.keyboard.audio.Scale
import com.tejando.keyboard.audio.SoundEngine
import com.tejando.keyboard.data.ClipboardStore
import com.tejando.keyboard.data.KeyboardPrefs
import com.tejando.keyboard.engine.LocalFixer
import com.tejando.keyboard.engine.LocalSuggestionEngine
import com.tejando.keyboard.keyboard.KeyboardView
import com.tejando.keyboard.keyboard.Layer
import com.tejando.keyboard.keyboard.ShiftState
import com.tejando.keyboard.security.CryptoBox
import kotlin.math.abs

enum class Status { PASS, FAIL, SKIP }
data class TestResult(val name: String, val status: Status, val detail: String)

/**
 * Testes que rodam NO APARELHO. Cada teste só marca PASS se medir o efeito real
 * (amostras de áudio com energia, frequência certa, estado do teclado após toques simulados).
 * O que depende de ouvido humano, internet, chave de API ou digital fica como SKIP com o motivo.
 */
class Diagnostics(private val ctx: Context) {
    private val ui = Handler(Looper.getMainLooper())
    private val out = ArrayList<TestResult>()

    private fun ok(n: String, d: String) = out.add(TestResult(n, Status.PASS, d))
    private fun bad(n: String, d: String) = out.add(TestResult(n, Status.FAIL, d))
    private fun skip(n: String, d: String) = out.add(TestResult(n, Status.SKIP, d))
    private fun check(n: String, cond: Boolean, good: String, wrong: String) { if (cond) ok(n, good) else bad(n, wrong) }

    /** Roda tudo em uma thread; [done] é chamado na thread principal. */
    fun runAll(done: (List<TestResult>) -> Unit) {
        Thread {
            safe("Áudio") { audioTests() }
            val latch = java.util.concurrent.CountDownLatch(1)
            ui.post { try { safe("Teclado") { keyboardTests() } } finally { latch.countDown() } }
            latch.await()
            safe("Dados") { dataTests() }
            ui.post { done(out.toList()) }
        }.start()
    }

    private fun safe(group: String, block: () -> Unit) {
        try { block() } catch (t: Throwable) { bad("$group: exceção", t.javaClass.simpleName + ": " + (t.message ?: "")) }
    }

    // ------------------------------------------------------------------ áudio

    private fun audioTests() {
        val eng = SoundEngine()
        val base = MixerState(volume = 80, echo = 0, reverb = 0, drive = 0, tone = 100)
        val a4 = 69
        for (inst in Instrument.MELODIC) {
            val x = eng.renderOffline(inst, a4, 0.5f, base)
            val rms = SoundEngine.rms(x)
            val hz = SoundEngine.estimateHz(x, eng.sampleRate, 0, (0.25f * eng.sampleRate).toInt())
            val pure = inst == Instrument.SYNTH_SAW || inst == Instrument.SYNTH_SQUARE || inst == Instrument.SYNTH_TRI || inst == Instrument.SYNTH_SINE
            val pitchOk = !pure || abs(hz - 440f) / 440f < 0.12f
            val note = if (pure) "~%.0f Hz (esperado 440)".format(hz) else "altura não medida (timbre com harmônicos)"
            check("Nota A4 · ${inst.label}", rms > 0.01f && pitchOk, "energia RMS %.3f, $note".format(rms), "RMS %.4f, $note".format(rms))
        }
        var drumsOk = 0
        val weak = ArrayList<String>()
        for (d in Drum.values()) {
            val rms = SoundEngine.rms(eng.renderDrumOffline(d))
            if (rms > 0.003f) drumsOk++ else weak.add(d.name)
        }
        check("Bateria (15 peças)", drumsOk == Drum.values().size, "todas produzem sinal", "sem sinal: $weak")

        // mixer altera o áudio de verdade
        val quiet = SoundEngine.rms(eng.renderOffline(Instrument.SYNTH_SAW, a4, 0.4f, base.copy(volume = 20)))
        val loud = SoundEngine.rms(eng.renderOffline(Instrument.SYNTH_SAW, a4, 0.4f, base.copy(volume = 90)))
        check("Mixer: volume", loud > quiet * 2f, "20%% → RMS %.3f, 90%% → RMS %.3f".format(quiet, loud), "volume não mudou o sinal (%.3f vs %.3f)".format(quiet, loud))

        val dry = eng.renderOffline(Instrument.PLUCK, a4, 1.2f, base.copy(echo = 0, reverb = 0))
        val wet = eng.renderOffline(Instrument.PLUCK, a4, 1.2f, base.copy(echo = 80, reverb = 80))
        val from = (0.9f * eng.sampleRate).toInt()
        val tailDry = SoundEngine.rms(dry.copyOfRange(from, dry.size))
        val tailWet = SoundEngine.rms(wet.copyOfRange(from, wet.size))
        check("Mixer: eco/reverb", tailWet > tailDry * 1.3f, "cauda seca %.4f, com efeito %.4f".format(tailDry, tailWet), "eco/reverb não alteraram a cauda (%.4f vs %.4f)".format(tailDry, tailWet))

        val o3 = SoundEngine.estimateHz(eng.renderOffline(Instrument.SYNTH_SINE, 57, 0.5f, base), eng.sampleRate, 0, 20000)
        val o4 = SoundEngine.estimateHz(eng.renderOffline(Instrument.SYNTH_SINE, 69, 0.5f, base), eng.sampleRate, 0, 20000)
        check("Mixer: oitava (notas 12 semitons acima)", abs(o4 / o3 - 2f) < 0.15f, "%.0f Hz → %.0f Hz".format(o3, o4), "razão %.2f (esperado 2.0)".format(o4 / o3))

        // mapeamento letras -> notas
        val s = Scale.PENT_MINOR
        val midis = ('a'..'z').map { c -> s.midi(base.baseMidi, KeyMap.degreeOf(c) ?: KeyMap.fallbackDegree(c)) }
        val distinct = midis.toSet().size
        val rising = KeyMap.degreeOf('z')!! < KeyMap.degreeOf('x')!! && KeyMap.degreeOf('a')!! < KeyMap.degreeOf('s')!! && KeyMap.degreeOf('q')!! < KeyMap.degreeOf('w')!!
        check("Mapeamento letras → notas", distinct >= 12 && rising, "$distinct notas distintas nas 26 letras, escala sobe da esquerda para a direita", "$distinct notas distintas; ordem coerente=$rising")

        // reprodução real no AudioTrack
        val live = SoundEngine()
        live.update(base.copy(enabled = true))
        live.start()
        val t0 = SystemClock.uptimeMillis()
        val f0 = live.framesRendered
        live.playNote(Instrument.PIANO, 69)
        var peak = 0f
        var firstMs = -1L
        for (i in 0 until 40) {
            Thread.sleep(10)
            if (live.peakLevel > peak) peak = live.peakLevel
            if (firstMs < 0 && live.peakLevel > 0.001f) firstMs = SystemClock.uptimeMillis() - t0
        }
        val err = live.lastError
        check("AudioTrack: amostras enviadas ao dispositivo", err == null && live.framesRendered > f0 && peak > 0.001f,
            "pico %.2f; primeira amostra audível no buffer após ~%d ms (só software, sem latência do hardware)".format(peak, firstMs),
            "erro=$err frames=${live.framesRendered - f0} pico=%.4f".format(peak))
        // toques rápidos
        for (i in 0 until 60) { live.playNote(Instrument.GUITAR, 55 + i % 12); if (i % 3 == 0) live.playDrum(Drum.HIHAT) }
        Thread.sleep(250)
        check("Toques sucessivos (60 notas em rajada)", live.lastError == null && live.peakLevel <= 1f, "sem erro, voz máxima ${SoundEngine.MAX_VOICES}", "erro=${live.lastError}")
        live.panic(); live.stop()
        skip("Som realmente audível / latência percebida", "Depende do seu ouvido e do aparelho: use os botões de ouvir na tela de Sons.")
    }

    // ------------------------------------------------------------------ teclado (toques simulados no KeyboardView real)

    private class Rec : KeyboardView.Listener {
        val typed = StringBuilder(); val downs = ArrayList<String>(); var deletes = 0; var enters = 0
        var mixed: MixerState? = null; val actions = ArrayList<String>()
        override fun onText(text: String) { typed.append(text) }
        override fun onDelete() { deletes++ }
        override fun onEnter() { enters++ }
        override fun onInputMethodPicker() {}
        override fun onSuggestionPicked(word: String) {}
        override fun onKeyDown(text: String) { downs.add(text) }
        override fun onAction(id: String) { actions.add(id) }
        override fun onMixerChanged(state: MixerState) { mixed = state }
        var cursor = 0
        override fun onCursorMove(delta: Int) { cursor += delta }
    }

    private fun mount(rec: Rec, style: com.tejando.keyboard.data.KeyboardStyle = com.tejando.keyboard.data.KeyboardStyle(haptic = false)): KeyboardView {
        val v = KeyboardView(ctx)
        v.listener = rec
        v.style = style
        val w = ctx.resources.displayMetrics.widthPixels
        v.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        v.layout(0, 0, v.measuredWidth, v.measuredHeight)
        return v
    }

    private fun tap(v: KeyboardView, label: String? = null, action: String? = null, gapMs: Long = 0): Boolean {
        val p = v.debugCenter(label, action) ?: return false
        val t = SystemClock.uptimeMillis()
        v.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, p.x, p.y, 0))
        v.dispatchTouchEvent(MotionEvent.obtain(t, t + 20, MotionEvent.ACTION_UP, p.x, p.y, 0))
        if (gapMs > 0) Thread.sleep(gapMs)
        return true
    }

    private fun keyboardTests() {
        // linha numérica + letras + som no toque
        val r = Rec()
        val v = mount(r)
        val digits = "1234567890"
        val missing = digits.filter { v.debugCenter(it.toString()) == null }
        val qOk = "qwertyuiop".all { v.debugCenter(it.toString()) != null }
        check("Layout: linha numérica 1234567890 permanente", missing.isEmpty() && v.debugRowCount() == 5, "10 teclas de número e 5 fileiras", "faltam: $missing, fileiras=${v.debugRowCount()}")
        check("Layout: qwertyuiop presente", qOk, "ok", "faltam teclas")
        for (d in digits) tap(v, d.toString())
        for (c in "qwerty") tap(v, c.toString())
        check("Digitação: números e letras inserem texto", r.typed.toString() == "1234567890qwerty", "inseriu \"${r.typed}\"", "inseriu \"${r.typed}\"")
        check("Som por tecla: toque dispara onKeyDown junto da letra", r.downs.size == 16 && r.downs.takeLast(6).joinToString("") == "qwerty",
            "16 toques → 16 eventos de som", "eventos=${r.downs.size}")

        // shift / caps
        val r2 = Rec(); val v2 = mount(r2)
        tap(v2, "shift"); val once = v2.debugShift()
        tap(v2, "a"); val afterA = v2.debugShift()
        tap(v2, "shift"); Thread.sleep(150); tap(v2, "shift"); val caps = v2.debugShift()
        tap(v2, "a"); val stillCaps = v2.debugShift()
        tap(v2, "shift"); val off = v2.debugShift()
        check("Shift: um toque = próxima maiúscula, volta sozinho", once == ShiftState.ONCE && afterA == ShiftState.OFF && r2.typed.toString() == "A", "ONCE → digita A → OFF", "once=$once afterA=$afterA texto=${r2.typed}")
        check("Caps Lock: toque duplo (150 ms entre toques)", caps == ShiftState.CAPS && stillCaps == ShiftState.CAPS, "ativou e permaneceu após digitar", "caps=$caps depois=$stillCaps")
        check("Caps Lock: novo toque desativa", off == ShiftState.OFF, "OFF", "estado=$off")
        val r3 = Rec(); val v3 = mount(r3)
        tap(v3, "shift"); Thread.sleep(700); tap(v3, "shift")
        check("Shift: dois toques LENTOS (700 ms) não viram Caps", v3.debugShift() != ShiftState.CAPS, "estado=${v3.debugShift()}", "virou Caps indevidamente")

        // delete / enter / espaço
        val r4 = Rec(); val v4 = mount(r4)
        tap(v4, "delete"); tap(v4, "enter"); tap(v4, " ")
        check("Backspace, Enter e espaço", r4.deletes == 1 && r4.enters == 1 && r4.typed.toString() == " ", "1 apagar, 1 enter, espaço", "del=${r4.deletes} enter=${r4.enters} texto='${r4.typed}'")

        // cursor pela barra de espaço (arrastar o dedo)
        val rc = Rec(); val vc = mount(rc)
        val sp = vc.debugCenter(" ")
        if (sp != null) {
            val t0 = SystemClock.uptimeMillis()
            vc.dispatchTouchEvent(MotionEvent.obtain(t0, t0, MotionEvent.ACTION_DOWN, sp.x, sp.y, 0))
            for (i in 1..6) vc.dispatchTouchEvent(MotionEvent.obtain(t0, t0 + i * 10L, MotionEvent.ACTION_MOVE, sp.x + i * 30f, sp.y, 0))
            vc.dispatchTouchEvent(MotionEvent.obtain(t0, t0 + 80, MotionEvent.ACTION_UP, sp.x + 180f, sp.y, 0))
            check("Cursor: deslizar na barra de espaço", rc.cursor > 0 && rc.typed.isEmpty(), "cursor andou ${rc.cursor} passos e nenhum espaço foi digitado", "passos=${rc.cursor} texto='${rc.typed}'")
        } else bad("Cursor: deslizar na barra de espaço", "barra de espaço não encontrada")

        // símbolos + mixer ao lado da vírgula
        val r5 = Rec(); val v5 = mount(r5)
        tap(v5, "!#1")
        val inSym = v5.currentLayer() == Layer.SYMBOLS
        val comma = v5.debugCenter(","); val mix = v5.debugCenter("MIX")
        val adjacent = comma != null && mix != null && abs(mix.y - comma.y) < 2f && mix.x > comma.x && (mix.x - comma.x) < v5.width * 0.25f
        check("Aba !#1 com botão MIX ao lado da vírgula", inSym && adjacent, "MIX logo à direita da vírgula", "inSym=$inSym adjacente=$adjacent")
        tap(v5, "MIX")
        check("MIX abre o mixer", v5.currentLayer() == Layer.MIXER, "camada MIXER", "camada=${v5.currentLayer()}")
        val before = v5.mixer.instrument
        tap(v5, action = "mix:instr:1")
        check("Mixer: botão + muda o instrumento e avisa o serviço", r5.mixed != null && r5.mixed!!.instrument != before, "${before.label} → ${r5.mixed?.instrument?.label}", "sem alteração")
        val volBefore = v5.mixer.volume
        tap(v5, action = "mix:vol:-1")
        check("Mixer: volume", r5.mixed?.volume == volBefore - 5, "$volBefore → ${r5.mixed?.volume}", "volume=${r5.mixed?.volume}")

        // emoji
        val r6 = Rec(); val v6 = mount(r6)
        tap(v6, "emoji")
        val inEmoji = v6.currentLayer() == Layer.EMOJI
        tap(v6, "😂")
        check("Emojis: abre painel e insere", inEmoji && r6.typed.toString() == "😂", "inseriu 😂", "camada=$inEmoji texto='${r6.typed}'")
        tap(v6, action = "emoji:cat:2")
        check("Emojis: troca de categoria", v6.debugCenter("🧡") != null, "categoria de corações exibida", "tecla 🧡 não encontrada")

        // redimensionamento
        val small = mount(Rec(), com.tejando.keyboard.data.KeyboardStyle(haptic = false, heightPct = 80))
        val big = mount(Rec(), com.tejando.keyboard.data.KeyboardStyle(haptic = false, heightPct = 140))
        check("Redimensionamento: altura 80% < 140%", big.measuredHeight > small.measuredHeight * 1.3f, "${small.measuredHeight}px → ${big.measuredHeight}px", "${small.measuredHeight} vs ${big.measuredHeight}")
        val narrow = mount(Rec(), com.tejando.keyboard.data.KeyboardStyle(haptic = false, widthPct = 80, align = 2))
        val pq = narrow.debugCenter("q"); val pp = narrow.debugCenter("p")
        check("Redimensionamento: largura 80% alinhada à direita", pq != null && pp != null && pq.x > narrow.width * 0.15f, "teclas deslocadas à direita", "q.x=${pq?.x}")
    }

    // ------------------------------------------------------------------ dados

    private fun dataTests() {
        // persistência do mixer
        val ms = MixerStore(ctx)
        val original = ms.load()
        val probe = original.copy(instrument = Instrument.GUITAR, scale = Scale.BLUES, root = 7, octave = 5, volume = 33, echo = 44, drumLayer = true)
        ms.save(probe)
        val back = MixerStore(ctx).load()
        ms.save(original)
        check("Persistência: mixer", back == probe, "valores voltaram iguais após salvar/ler", "diferente: $back")
        val prefs = KeyboardPrefs(ctx)
        val oh = prefs.heightPct; prefs.heightPct = 123
        val okp = KeyboardPrefs(ctx).heightPct == 123; prefs.heightPct = oh
        check("Persistência: tamanho do teclado", okp, "ok", "não persistiu")

        // sugestões / correção
        val eng = LocalSuggestionEngine(ctx)
        eng.personalize = false
        val s1 = eng.suggest("voc")
        check("Sugestões: completar palavra (\"voc\")", s1.isNotEmpty(), s1.joinToString(), "nenhuma sugestão")
        val s2 = eng.suggest("voce")
        check("Sugestões: ignora acento (\"voce\" → você)", s2.any { it.equals("você", true) }, s2.joinToString(), "retornou: $s2")
        val fix = LocalFixer.fix("oi  ,tudo bem ?  vamos")
        check("Correção local (espaços e maiúsculas, sem reescrever)", fix == "Oi, tudo bem? Vamos", "\"$fix\"", "\"$fix\"")

        // área de transferência
        val cs = ClipboardStore(ctx); val backup = cs.all()
        cs.clearAll(); cs.add("teste-a"); cs.add("teste-b"); cs.togglePin("teste-a"); cs.clearUnpinned()
        val left = cs.all().map { it.text }
        cs.clearAll(); backup.reversed().forEach { cs.add(it.text); if (it.pinned) cs.togglePin(it.text) }
        check("Área de transferência: adicionar, fixar, apagar histórico", left == listOf("teste-a"), "fixado sobrevive ao apagar", "restou $left")

        // cripto
        val enc = CryptoBox.encryptPlain("segredo-123")
        check("Cripto (Keystore): chave de API cifrada", enc != "segredo-123" && CryptoBox.decryptPlain(enc) == "segredo-123", "cifra e decifra", "falhou")

        val bm = androidx.biometric.BiometricManager.from(ctx).canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
        skip("Cofre de senhas com digital", if (bm == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS)
            "Biometria disponível, mas só dá para testar tocando o sensor: abra o Cofre e salve/abra um item." else "Sem biometria forte cadastrada neste aparelho (código $bm).")
        skip("Tradução", "Exige internet + provedor de IA com chave. Use Provedores de IA > Testar conexão.")
        skip("Provedores de IA / correção por IA", "Exige internet + chave de API. Use Provedores de IA > Testar conexão.")
        skip("Ditado por voz, GIFs, cursor pela barra de espaço, desfazer/refazer", "Não implementados nesta versão.")
    }
}
