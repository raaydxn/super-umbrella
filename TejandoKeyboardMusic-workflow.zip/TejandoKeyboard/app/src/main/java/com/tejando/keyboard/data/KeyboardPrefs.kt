package com.tejando.keyboard.data

import android.content.Context

/** Parâmetros visuais e de tamanho usados pelo KeyboardView. */
data class KeyboardStyle(
    /** 0..90 — quanto escurecer o papel de parede. */
    val dim: Int = 35,
    /** 0..100 — opacidade das teclas. */
    val keyOpacity: Int = 65,
    /** 0..100 — posição vertical do recorte da imagem. */
    val focusY: Int = 50,
    val haptic: Boolean = true,
    /** 70..150 — altura das teclas em % do padrão (altura total do teclado). */
    val heightPct: Int = 100,
    /** 0..10 — espaçamento entre teclas, em dp. */
    val gapDp: Int = 3,
    /** 70..100 — largura do teclado em % da tela. */
    val widthPct: Int = 100,
    /** 0 = centro, 1 = esquerda, 2 = direita (modo uma mão quando a largura < 100). */
    val align: Int = 0,
    /** 80..180 — largura das teclas de função (Shift, apagar, Enter...) em % do padrão. */
    val fnPct: Int = 100,
)

/** Preferências do teclado. Activity e Service rodam no mesmo processo e compartilham isto. */
class KeyboardPrefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("tejando_prefs", Context.MODE_PRIVATE)

    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun put(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var dim: Int get() = int("dim", 35); set(v) = put("dim", v)
    var keyOpacity: Int get() = int("key_opacity", 65); set(v) = put("key_opacity", v)
    var focusY: Int get() = int("focus_y", 50); set(v) = put("focus_y", v)
    var haptic: Boolean get() = bool("haptic", true); set(v) = put("haptic", v)
    var suggestions: Boolean get() = bool("suggestions", true); set(v) = put("suggestions", v)
    var heightPct: Int get() = int("height_pct", 100); set(v) = put("height_pct", v)
    var gapDp: Int get() = int("gap_dp", 3); set(v) = put("gap_dp", v)
    var widthPct: Int get() = int("width_pct", 100); set(v) = put("width_pct", v)
    var align: Int get() = int("align", 0); set(v) = put("align", v)
    var fnPct: Int get() = int("fn_pct", 100); set(v) = put("fn_pct", v)

    /** Silencia o áudio em campos de senha (o som por tecla revelaria o que é digitado). */
    var muteInPasswords: Boolean get() = bool("mute_pw", true); set(v) = put("mute_pw", v)

    /** Modo privado: sem sugestões personalizadas, sem aprender palavras, sem IA, sem histórico da área de transferência. */
    var privateMode: Boolean get() = bool("private_mode", false); set(v) = put("private_mode", v)

    var learnWords: Boolean get() = bool("learn_words", true); set(v) = put("learn_words", v)
    var translateTarget: String
        get() = sp.getString("translate_target", "en") ?: "en"
        set(v) = sp.edit().putString("translate_target", v).apply()

    fun style() = KeyboardStyle(dim, keyOpacity, focusY, haptic, heightPct, gapDp, widthPct, align, fnPct)

    fun resetSizes() {
        heightPct = 100; gapDp = 3; widthPct = 100; align = 0; fnPct = 100
    }
}
