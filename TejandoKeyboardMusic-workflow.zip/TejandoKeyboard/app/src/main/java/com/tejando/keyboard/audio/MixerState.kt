package com.tejando.keyboard.audio

import android.content.Context

/**
 * Todos os parâmetros do mixer. Persistidos em SharedPreferences ("tejando_mixer"),
 * compartilhados entre o teclado (IME) e o app, no mesmo processo.
 * Valores 0..100 são percentuais.
 */
data class MixerState(
    val enabled: Boolean = true,          // som ligado (digitação nunca depende disso)
    val volume: Int = 75,                 // geral
    val instrument: Instrument = Instrument.PIANO,   // letras (melodia)
    val drumLayer: Boolean = false,       // bateria junto, tocando por cima da melodia
    val drumVolume: Int = 70,
    val digitInstrument: Instrument = Instrument.PLUCK,  // números
    val spaceInstrument: Instrument = Instrument.DRUMS,  // espaço
    val punctInstrument: Instrument = Instrument.SYNTH_SQUARE,
    val scale: Scale = Scale.PENT_MINOR,
    val root: Int = 9,                    // 0=C ... 9=A
    val octave: Int = 3,                  // oitava base (C4 = 60)
    val noteLen: Int = 50,                // duração das notas
    val echo: Int = 20,
    val reverb: Int = 20,
    val drive: Int = 10,
    val tone: Int = 74,
    val bpm: Int = 96,
    val clickFx: Boolean = false,         // clique mecânico opcional
) {
    val baseMidi: Int get() = (octave + 1) * 12 + root
    val noteSeconds: Float get() = 0.15f + noteLen / 100f * 1.6f
}

class MixerStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("tejando_mixer", Context.MODE_PRIVATE)

    fun load(): MixerState {
        val d = MixerState()
        fun <T : Enum<T>> en(key: String, all: Array<T>, def: T) = all.getOrElse(sp.getInt(key, def.ordinal)) { def }
        return MixerState(
            enabled = sp.getBoolean("enabled", d.enabled),
            volume = sp.getInt("volume", d.volume),
            instrument = en("instrument", Instrument.values(), d.instrument),
            drumLayer = sp.getBoolean("drumLayer", d.drumLayer),
            drumVolume = sp.getInt("drumVolume", d.drumVolume),
            digitInstrument = en("digitInstrument", Instrument.values(), d.digitInstrument),
            spaceInstrument = en("spaceInstrument", Instrument.values(), d.spaceInstrument),
            punctInstrument = en("punctInstrument", Instrument.values(), d.punctInstrument),
            scale = en("scale", Scale.values(), d.scale),
            root = sp.getInt("root", d.root).coerceIn(0, 11),
            octave = sp.getInt("octave", d.octave).coerceIn(1, 6),
            noteLen = sp.getInt("noteLen", d.noteLen),
            echo = sp.getInt("echo", d.echo),
            reverb = sp.getInt("reverb", d.reverb),
            drive = sp.getInt("drive", d.drive),
            tone = sp.getInt("tone", d.tone),
            bpm = sp.getInt("bpm", d.bpm),
            clickFx = sp.getBoolean("clickFx", d.clickFx),
        )
    }

    fun save(s: MixerState) {
        sp.edit()
            .putBoolean("enabled", s.enabled).putInt("volume", s.volume)
            .putInt("instrument", s.instrument.ordinal).putBoolean("drumLayer", s.drumLayer)
            .putInt("drumVolume", s.drumVolume).putInt("digitInstrument", s.digitInstrument.ordinal)
            .putInt("spaceInstrument", s.spaceInstrument.ordinal).putInt("punctInstrument", s.punctInstrument.ordinal)
            .putInt("scale", s.scale.ordinal).putInt("root", s.root).putInt("octave", s.octave)
            .putInt("noteLen", s.noteLen).putInt("echo", s.echo).putInt("reverb", s.reverb)
            .putInt("drive", s.drive).putInt("tone", s.tone).putInt("bpm", s.bpm)
            .putBoolean("clickFx", s.clickFx).apply()
    }

    fun reset(): MixerState = MixerState().also { save(it) }
}
