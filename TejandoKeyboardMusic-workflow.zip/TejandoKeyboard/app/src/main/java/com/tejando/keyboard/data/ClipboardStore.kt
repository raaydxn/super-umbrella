package com.tejando.keyboard.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipEntry(val text: String, val pinned: Boolean)

/**
 * Histórico local da área de transferência (só neste aparelho, em SharedPreferences privado).
 * O Android só entrega o conteúdo copiado ao teclado enquanto ele é o teclado ativo e está em foco.
 * Nada é guardado em modo privado nem em campos de senha (decisão do chamador).
 */
class ClipboardStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("tejando_clip", Context.MODE_PRIVATE)

    fun all(): List<ClipEntry> {
        val raw = sp.getString("items", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { val o = arr.getJSONObject(it); ClipEntry(o.getString("t"), o.optBoolean("p")) }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(list: List<ClipEntry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.text).put("p", it.pinned)) }
        sp.edit().putString("items", arr.toString()).apply()
    }

    fun add(text: String) {
        val t = text.trim()
        if (t.isEmpty() || t.length > 2000) return
        val cur = all().toMutableList()
        val old = cur.firstOrNull { it.text == t }
        cur.removeAll { it.text == t }
        cur.add(0, ClipEntry(t, old?.pinned ?: false))
        val pinned = cur.filter { it.pinned }
        val rest = cur.filter { !it.pinned }.take(30)
        save(pinned + rest)
    }

    fun togglePin(text: String) = save(all().map { if (it.text == text) it.copy(pinned = !it.pinned) else it })
    fun remove(text: String) = save(all().filter { it.text != text })
    /** Apaga o histórico mas preserva os itens fixados. */
    fun clearUnpinned() = save(all().filter { it.pinned })
    fun clearAll() = save(emptyList())
}
