package com.tejando.keyboard.audio

import kotlin.math.pow

/** Instrumentos (timbres) do motor próprio. Portado do SoundEngine do grok-workspace. */
enum class Instrument(val label: String) {
    SYNTH_SAW("Synth"), SYNTH_SQUARE("Square"), SYNTH_TRI("Triangle"), SYNTH_SINE("Sine"),
    GUITAR("Guitarra"), PIANO("Piano"), BASS("Baixo"), PLUCK("Pluck"), DRUMS("Bateria"), OFF("Mudo");

    companion object {
        val MELODIC = listOf(SYNTH_SAW, SYNTH_SQUARE, SYNTH_TRI, SYNTH_SINE, GUITAR, PIANO, BASS, PLUCK)
        val ALL = values().toList()
    }
}

enum class Drum {
    KICK, SNARE, HIHAT, OPENHAT, CLAP, RIM, TOM_HI, TOM_MID, TOM_LO, CRASH, RIDE, COWBELL, SHAKER, CLAVE, CONGA
}

/** Escalas: intervalos em semitons dentro da oitava. */
enum class Scale(val label: String, val steps: IntArray) {
    MAJOR("Maior", intArrayOf(0, 2, 4, 5, 7, 9, 11)),
    MINOR("Menor natural", intArrayOf(0, 2, 3, 5, 7, 8, 10)),
    PENT_MAJOR("Pentatônica maior", intArrayOf(0, 2, 4, 7, 9)),
    PENT_MINOR("Pentatônica menor", intArrayOf(0, 3, 5, 7, 10)),
    BLUES("Blues", intArrayOf(0, 3, 5, 6, 7, 10)),
    DORIAN("Dórica", intArrayOf(0, 2, 3, 5, 7, 9, 10)),
    CHROMATIC("Cromática", intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11));

    /** Nota MIDI do grau [degree] (pode ser negativo ou maior que a escala) a partir da tônica [root]. */
    fun midi(root: Int, degree: Int): Int {
        val n = steps.size
        val oct = Math.floorDiv(degree, n)
        val idx = Math.floorMod(degree, n)
        return root + oct * 12 + steps[idx]
    }
}

object Notes {
    val NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    fun label(midi: Int) = NAMES[Math.floorMod(midi, 12)] + (Math.floorDiv(midi, 12) - 1)
    fun freq(midi: Double) = 440.0 * 2.0.pow((midi - 69.0) / 12.0)
}

/**
 * Mapeamento tecla -> evento musical.
 * Letras QWERTY viram graus consecutivos da escala, na ordem física do teclado
 * (grave embaixo, agudo em cima), então digitar "asdf" sobe a escala.
 * Vogais ainda podem disparar bateria quando o modo "camada de bateria" está ligado.
 */
object KeyMap {
    private const val BOTTOM = "zxcvbnm"
    private const val HOME = "asdfghjkl"
    private const val TOP = "qwertyuiop"
    private const val DIGITS = "1234567890"

    enum class Group { TOP, HOME, BOTTOM, DIGIT, PUNCT, SPACE }

    fun groupOf(ch: Char): Group? = when {
        ch == ' ' -> Group.SPACE
        ch.lowercaseChar() in TOP -> Group.TOP
        ch.lowercaseChar() in HOME -> Group.HOME
        ch.lowercaseChar() in BOTTOM -> Group.BOTTOM
        ch in DIGITS -> Group.DIGIT
        ch.isLetter() -> Group.TOP // acentuadas: tratadas como letra
        else -> Group.PUNCT
    }

    /**
     * Grau da escala (0 = grave). Cada fileira começa um pouco acima da de baixo, como num piano de 3
     * andares, para o teclado inteiro cobrir cerca de 3 oitavas em vez de 5.
     * Embaixo z..m = 0..6, no meio a..l = 2..10, em cima q..p = 5..14, números = 8..17.
     */
    fun degreeOf(ch: Char): Int? {
        val c = ch.lowercaseChar()
        BOTTOM.indexOf(c).let { if (it >= 0) return it }
        HOME.indexOf(c).let { if (it >= 0) return 2 + it }
        TOP.indexOf(c).let { if (it >= 0) return 5 + it }
        DIGITS.indexOf(c).let { if (it >= 0) return 8 + it }
        return null
    }

    /** Pontuação e letras acentuadas: grau fixo derivado do caractere, para soar sempre igual. */
    fun fallbackDegree(ch: Char): Int = 3 + Math.floorMod(ch.code, 9)

    fun drumOf(ch: Char): Drum? = when (ch.lowercaseChar()) {
        'z', 'b' -> Drum.KICK
        'x', 'n' -> Drum.SNARE
        'c', 'v' -> Drum.HIHAT
        'a' , 'e', 'i', 'o', 'u' -> Drum.CONGA
        's' -> Drum.CLAP
        'd' -> Drum.RIM
        'f' -> Drum.TOM_MID
        'g' -> Drum.TOM_HI
        'h' -> Drum.TOM_LO
        'j' -> Drum.COWBELL
        'k' -> Drum.CLAVE
        'l' -> Drum.SHAKER
        'q' -> Drum.CRASH
        'w' -> Drum.RIDE
        'm' -> Drum.OPENHAT
        ' ' -> Drum.KICK
        else -> null
    }
}
