package com.tejando.keyboard.vault

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Entrada do cofre: título em texto puro (para listar), e usuário+senha cifrados por chave que exige a digital. */
data class VaultEntry(val id: String, val title: String, val payload: String)

class VaultStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("tejando_vault", Context.MODE_PRIVATE)

    fun all(): List<VaultEntry> = try {
        val a = JSONArray(sp.getString("entries", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); VaultEntry(o.getString("id"), o.getString("t"), o.getString("p")) }
    } catch (_: Exception) { emptyList() }

    private fun save(list: List<VaultEntry>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("p", it.payload)) }
        sp.edit().putString("entries", a.toString()).apply()
    }

    fun add(title: String, payload: String) = save(all() + VaultEntry(System.currentTimeMillis().toString(), title, payload))
    fun remove(id: String) = save(all().filter { it.id != id })
    fun wipe() = save(emptyList())
}
