package com.tejando.keyboard.engine

import android.content.Context
import com.tejando.keyboard.R
import java.text.Normalizer

/**
 * Sugestões 100% locais, sem internet:
 *  1. palavras que o usuário já usou ([UserWords]), mais frequentes primeiro
 *  2. lista de palavras em res/raw/palavras_pt.txt por prefixo (ignora acentos: "voce" -> "você")
 *  3. correção: se nada começa com o que foi digitado, procura palavras a 1 edição de distância
 *  4. depois de uma palavra + espaço, sugere pontuação
 */
class LocalSuggestionEngine(private val context: Context) : SuggestionEngine {

    val userWords = UserWords(context)
    var personalize = true

    private val words: List<String> by lazy {
        context.resources.openRawResource(R.raw.palavras_pt)
            .bufferedReader(Charsets.UTF_8)
            .useLines { lines -> lines.map { it.trim() }.filter { it.isNotEmpty() }.toList() }
    }

    private val folded: List<String> by lazy { words.map { fold(it) } }

    override fun suggest(textBeforeCursor: String, max: Int): List<String> {
        val prefix = currentWordPrefix(textBeforeCursor)
        if (prefix.isEmpty()) {
            if (textBeforeCursor.isBlank()) return STARTERS.take(max)
            if (textBeforeCursor.endsWith(" ") && textBeforeCursor.trimEnd().lastOrNull()?.isLetterOrDigit() == true) {
                return PUNCT.take(max)
            }
            return emptyList()
        }
        val key = fold(prefix)
        val out = LinkedHashSet<String>()
        if (personalize) {
            for (w in userWords.matching(key) { fold(it) }) {
                if (fold(w).length > key.length) out.add(matchCase(prefix, w))
                if (out.size >= max) return out.toList()
            }
        }
        for (i in words.indices) {
            val f = folded[i]
            if (f.length > key.length && f.startsWith(key)) {
                out.add(matchCase(prefix, words[i]))
                if (out.size >= max) return out.toList()
            }
        }
        if (out.isEmpty() && key.length >= 3) {
            // correção ortográfica simples: 1 edição de distância, mesma primeira letra
            for (i in words.indices) {
                val f = folded[i]
                if (f.isNotEmpty() && f[0] == key[0] && kotlin.math.abs(f.length - key.length) <= 1 && editDistance1(f, key)) {
                    out.add(matchCase(prefix, words[i]))
                    if (out.size >= max) break
                }
            }
        }
        return out.toList()
    }

    private fun editDistance1(a: String, b: String): Boolean {
        if (a == b) return false
        if (a.length == b.length) {
            var diff = 0
            for (i in a.indices) if (a[i] != b[i]) diff++
            if (diff == 1) return true
            // transposição de duas letras vizinhas
            for (k in 0 until a.length - 1) {
                if (a[k] == b[k + 1] && a[k + 1] == b[k] && a.substring(0, k) == b.substring(0, k) && a.substring(k + 2) == b.substring(k + 2)) return true
            }
            return false
        }
        val (longer, shorter) = if (a.length > b.length) a to b else b to a
        var i = 0
        while (i < shorter.length && longer[i] == shorter[i]) i++
        return longer.substring(i + 1) == shorter.substring(i)
    }

    private fun fold(s: String): String =
        MARKS.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")

    private fun matchCase(typed: String, word: String): String = when {
        typed.length > 1 && typed.all { it.isUpperCase() } -> word.uppercase()
        typed.first().isUpperCase() -> word.replaceFirstChar { it.uppercase() }
        else -> word
    }

    private companion object {
        val MARKS = Regex("\\p{M}+")
        val STARTERS = listOf("Oi", "Olá", "Tudo bem?")
        val PUNCT = listOf(".", ",", "?")
    }
}

/** Vocabulário pessoal, guardado só no aparelho. Desligado no modo privado. */
class UserWords(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("tejando_userwords", Context.MODE_PRIVATE)

    fun learn(word: String) {
        val w = word.trim()
        if (w.length < 3 || w.length > 24 || !w.all { it.isLetter() }) return
        val k = w.lowercase()
        sp.edit().putInt(k, sp.getInt(k, 0) + 1).apply()
    }

    fun matching(foldedPrefix: String, fold: (String) -> String): List<String> =
        sp.all.entries.filter { fold(it.key).startsWith(foldedPrefix) && (it.value as? Int ?: 0) >= 2 }
            .sortedByDescending { it.value as? Int ?: 0 }.map { it.key }.take(3)

    fun clear() = sp.edit().clear().apply()
    fun count() = sp.all.size
}

/** Correção local: só espaçamento e maiúsculas. Não reescreve, não formaliza, não mexe em gírias. */
object LocalFixer {
    fun fix(text: String): String {
        var s = text.replace(Regex("[ \\t]+"), " ")
        s = s.replace(Regex(" +([,.;:!?])"), "$1")
        s = s.replace(Regex("([,;])(?=\\p{L})"), "$1 ")
        val sb = StringBuilder()
        var cap = true
        for (ch in s) {
            if (cap && ch.isLetter()) { sb.append(ch.uppercaseChar()); cap = false }
            else {
                sb.append(ch)
                if (ch == '.' || ch == '!' || ch == '?' || ch == '\n') cap = true
                else if (!ch.isWhitespace()) cap = false
            }
        }
        return sb.toString().trim()
    }
}
