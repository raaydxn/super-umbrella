package com.tejando.keyboard.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.AdapterView

/** Pequenos construtores de tela feitos em código, na paleta do teclado (marrom escuro + laranja). */
object Ui {
    const val BG = 0xFF14120E.toInt()
    const val SURFACE = 0xFF1E1B16.toInt()
    const val FG = 0xFFF4EFE6.toInt()
    const val MUTED = 0xFFA39888.toInt()
    const val ACCENT = 0xFFE8893A.toInt()
    const val ACCENT_INK = 0xFF1A1008.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun screen(c: Context, content: LinearLayout): ScrollView {
        content.orientation = LinearLayout.VERTICAL
        val p = dp(c, 18)
        content.setPadding(p, p, p, p * 2)
        return ScrollView(c).apply { setBackgroundColor(BG); isFillViewport = true; addView(content) }
    }

    fun root(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

    fun title(c: Context, t: String) = TextView(c).apply {
        text = t; setTextColor(FG); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(c, 6))
    }

    fun section(c: Context, t: String) = TextView(c).apply {
        text = t; setTextColor(ACCENT); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(c, 18), 0, dp(c, 6))
    }

    fun note(c: Context, t: String) = TextView(c).apply {
        text = t; setTextColor(MUTED); textSize = 13f; setPadding(0, dp(c, 2), 0, dp(c, 8))
    }

    fun label(c: Context, t: String) = TextView(c).apply { text = t; setTextColor(FG); textSize = 15f }

    fun button(c: Context, t: String, primary: Boolean = true, onClick: () -> Unit) = Button(c).apply {
        text = t; isAllCaps = false
        setTextColor(if (primary) ACCENT_INK else FG)
        background = GradientDrawable().apply {
            cornerRadius = dp(c, 14).toFloat(); setColor(if (primary) ACCENT else 0xFF3A342B.toInt())
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48)).apply { topMargin = dp(c, 8) }
    }

    fun edit(c: Context, hint: String, value: String = "", password: Boolean = false) = EditText(c).apply {
        setHint(hint); setText(value); setTextColor(FG); setHintTextColor(MUTED)
        inputType = if (password) 0x81 /* textPassword */ else 0x1
        setSingleLine(true)
    }

    fun seek(c: Context, name: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 2)) }
        val tv = TextView(c).apply { setTextColor(FG); textSize = 14f; text = "$name: ${fmt(value)}" }
        val sb = SeekBar(c).apply {
            this.max = max - min; progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$name: ${fmt(p + min)}"
                    if (fromUser) onChange(p + min)
                }
                override fun onStartTrackingTouch(s: SeekBar?) = Unit
                override fun onStopTrackingTouch(s: SeekBar?) = Unit
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }

    fun toggle(c: Context, name: String, value: Boolean, onChange: (Boolean) -> Unit) = Switch(c).apply {
        text = name; setTextColor(FG); textSize = 15f; isChecked = value
        setPadding(0, dp(c, 8), 0, dp(c, 8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    fun <T> choice(c: Context, name: String, items: List<T>, selected: Int, text: (T) -> String, onPick: (T) -> Unit): View {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 2)) }
        box.addView(TextView(c).apply { this.text = name; setTextColor(FG); textSize = 14f })
        val sp = Spinner(c)
        val ad = object : ArrayAdapter<String>(c, android.R.layout.simple_spinner_dropdown_item, items.map(text)) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).also { it.setTextColor(FG) }
        }
        sp.adapter = ad
        sp.setSelection(selected.coerceIn(0, items.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onPick(items[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) = Unit
        }
        box.addView(sp)
        return box
    }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
}
