package com.tejando.keyboard.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM com chave guardada no Android Keystore (a chave nunca sai do hardware/TEE).
 *
 *  - [Plain]: chave sem autenticação, usada para a chave de API (protegida em repouso).
 *  - [Biometric]: chave que exige a digital a CADA uso (CryptoObject), usada no cofre de senhas.
 *    Se o usuário cadastrar uma nova digital, o Android invalida a chave e o cofre precisa ser recriado.
 */
object CryptoBox {
    private const val PROVIDER = "AndroidKeyStore"
    private const val TRANSFORM = "AES/GCM/NoPadding"
    const val ALIAS_PLAIN = "tejando_plain_v1"
    const val ALIAS_VAULT = "tejando_vault_v1"

    private fun ks(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    private fun key(alias: String, biometric: Boolean): SecretKey {
        val store = ks()
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val b = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
        if (biometric) {
            b.setUserAuthenticationRequired(true)
            b.setInvalidatedByBiometricEnrollment(true)
            if (Build.VERSION.SDK_INT >= 30) {
                b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            }
        }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        g.init(b.build())
        return g.generateKey()
    }

    fun deleteVaultKey() { try { ks().deleteEntry(ALIAS_VAULT) } catch (_: Exception) {} }
    fun hasVaultKey(): Boolean = try { ks().containsAlias(ALIAS_VAULT) } catch (_: Exception) { false }

    // ---- sem digital (chave de API)

    fun encryptPlain(text: String): String {
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key(ALIAS_PLAIN, false))
        return pack(c.iv, c.doFinal(text.toByteArray(Charsets.UTF_8)))
    }

    fun decryptPlain(packed: String): String? = try {
        val (iv, ct) = unpack(packed)
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.DECRYPT_MODE, key(ALIAS_PLAIN, false), GCMParameterSpec(128, iv))
        String(c.doFinal(ct), Charsets.UTF_8)
    } catch (_: Exception) { null }

    // ---- com digital: o BiometricPrompt precisa receber o Cipher já inicializado

    fun vaultEncryptCipher(): Cipher {
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key(ALIAS_VAULT, true))
        return c
    }

    fun vaultDecryptCipher(packed: String): Cipher {
        val (iv, _) = unpack(packed)
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.DECRYPT_MODE, key(ALIAS_VAULT, true), GCMParameterSpec(128, iv))
        return c
    }

    fun finishEncrypt(c: Cipher, text: String): String = pack(c.iv, c.doFinal(text.toByteArray(Charsets.UTF_8)))

    fun finishDecrypt(c: Cipher, packed: String): String = String(c.doFinal(unpack(packed).second), Charsets.UTF_8)

    private fun pack(iv: ByteArray, ct: ByteArray) =
        Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)

    private fun unpack(s: String): Pair<ByteArray, ByteArray> {
        val i = s.indexOf(':')
        return Base64.decode(s.substring(0, i), Base64.NO_WRAP) to Base64.decode(s.substring(i + 1), Base64.NO_WRAP)
    }
}
