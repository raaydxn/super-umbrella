package com.tejando.keyboard.keyboard

/** Camadas do teclado. MIXER, CLIPBOARD e RESULT são montadas dinamicamente pelo KeyboardView. */
enum class Layer { LETTERS, SYMBOLS, SYMBOLS_2, EMOJI, MIXER, CLIPBOARD, RESULT }

/** Estado do Shift: desligado, uma letra (ONCE) ou Caps Lock (CAPS). */
enum class ShiftState { OFF, ONCE, CAPS }

enum class KeyType { CHAR, SHIFT, DELETE, ENTER, SPACE, SWITCH_LAYER, EMOJI_TOGGLE, SPACER, ACTION }

/**
 * Uma tecla do layout.
 *
 * @param label       texto mostrado e, para teclas CHAR, texto digitado.
 * @param weight      largura relativa dentro da linha.
 * @param hint        dica pequena no canto da tecla; também é digitada no toque longo.
 * @param alternates  variantes mostradas no toque longo (acentos etc.).
 * @param targetLayer camada para onde teclas SWITCH_LAYER / EMOJI_TOGGLE levam.
 * @param action      id da ação para teclas ACTION (ex.: "mix:instr:+1"). Tratado pelo KeyboardView/Service.
 * @param longAction  ação disparada no toque longo de uma tecla ACTION.
 * @param active      destaque visual (toggle ligado, categoria selecionada).
 */
data class Key(
    val label: String,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val hint: String? = null,
    val alternates: List<String> = emptyList(),
    val targetLayer: Layer? = null,
    val action: String? = null,
    val longAction: String? = null,
    val active: Boolean = false,
) {
    val popupItems: List<String>
        get() = buildList {
            addAll(alternates)
            hint?.let { add(it) }
        }
}

/** Categorias de emoji (dados próprios, lista curada; não há atualização automática). */
object EmojiData {
    val CATEGORIES: List<Pair<String, List<String>>> = listOf(
        "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😜 🤪 😝 🤗 🤭 🤫 🤔 🤐 😐 😑 😶 😏 😒 🙄 😬 😮 😯 😲 😳 🥺 😢 😭 😤 😠 😡 🤬 😱 😨 😰 😥 😓 😴 😪 🥳 😎 🤓 🥵 🥶 🤯 😵".split(" "),
        "👍" to "👍 👎 👊 ✊ 🤛 🤜 👏 🙌 👐 🤝 🙏 ✌️ 🤞 🤟 🤘 👌 🤏 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 👋 💪 🦾 ✍️ 🙋 🤷 🤦 🙇 💁".split(" "),
        "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 🔥 ✨ ⭐ 🌟 ⚡ 🎉 🎊 🎁".split(" "),
        "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦆 🦉 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐬 🐳 🌵 🌴 🌸 🌻 🌈 ☀️ 🌙 ⛅ ☔ ❄️".split(" "),
        "🍕" to "🍎 🍌 🍇 🍉 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🍞 🧀 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🌯 🍣 🍜 🍝 🍰 🍩 🍪 🍫 🍿 ☕ 🍺 🍷 🥤".split(" "),
        "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🥊 🎯 🎮 🎲 🎸 🎹 🥁 🎷 🎺 🎻 🎤 🎧 🎬 🏆 🥇 🚗 ✈️ 🚀 🏠 📱 💻 📷 💡 📚 ✏️ 💰 🔑 🔒".split(" "),
    )
}

/** Teclas padrão. As camadas dinâmicas (MIXER etc.) são montadas no KeyboardView. */
object KeyboardLayouts {

    fun rows(layer: Layer): List<List<Key>> = when (layer) {
        Layer.LETTERS -> LETTERS
        Layer.SYMBOLS -> SYMBOLS
        Layer.SYMBOLS_2 -> SYMBOLS_2
        else -> emptyList()
    }

    private val ACCENTS = mapOf(
        "a" to listOf("á", "à", "â", "ã", "ä"),
        "e" to listOf("é", "ê", "è", "ë"),
        "i" to listOf("í", "î", "ì", "ï"),
        "o" to listOf("ó", "ô", "õ", "ò", "ö"),
        "u" to listOf("ú", "ü", "ù", "û"),
        "c" to listOf("ç"),
        "n" to listOf("ñ"),
    )

    private fun letterRow(letters: String): List<Key> =
        letters.map { ch -> val s = ch.toString(); Key(label = s, alternates = ACCENTS[s].orEmpty()) }

    /** Linha numérica permanente: 1234567890, com o símbolo do Samsung/Gboard no toque longo. */
    private fun numberRow(): List<Key> {
        val alt = mapOf(
            "1" to "!", "2" to "@", "3" to "#", "4" to "$", "5" to "%",
            "6" to "^", "7" to "&", "8" to "*", "9" to "(", "0" to ")",
        )
        return "1234567890".map { Key(label = it.toString(), alternates = listOfNotNull(alt[it.toString()])) }
    }

    private fun charRow(chars: String): List<Key> = chars.map { Key(it.toString()) }
    private fun spacer(weight: Float) = Key("", KeyType.SPACER, weight)
    private fun shiftKey() = Key("shift", KeyType.SHIFT, 1.5f)
    private fun deleteKey() = Key("delete", KeyType.DELETE, 1.5f)

    /** Na aba !#1 a tecla ao lado da vírgula abre o mixer; nas demais, os emojis. */
    private fun bottomRow(switchLabel: String, switchTo: Layer, mixerNextToComma: Boolean): List<Key> = listOf(
        Key(switchLabel, KeyType.SWITCH_LAYER, 1.5f, targetLayer = switchTo),
        Key(","),
        if (mixerNextToComma) Key("MIX", KeyType.SWITCH_LAYER, 1.2f, targetLayer = Layer.MIXER)
        else Key("emoji", KeyType.EMOJI_TOGGLE, 1f, targetLayer = Layer.EMOJI),
        Key(" ", KeyType.SPACE, 4f),
        Key(".", alternates = listOf("?", "!", ":", ";", "…", "-")),
        Key("enter", KeyType.ENTER, 1.5f),
    )

    private val LETTERS: List<List<Key>> = listOf(
        numberRow(),
        letterRow("qwertyuiop"),
        listOf(spacer(0.5f)) + letterRow("asdfghjkl") + listOf(spacer(0.5f)),
        listOf(shiftKey()) + letterRow("zxcvbnm") + listOf(deleteKey()),
        bottomRow("!#1", Layer.SYMBOLS, false),
    )

    private val SYMBOLS: List<List<Key>> = listOf(
        numberRow(),
        charRow("@#\$_&-+()/"),
        charRow("£€¥%*\"':;"),
        listOf(Key("=\\<", KeyType.SWITCH_LAYER, 1.5f, targetLayer = Layer.SYMBOLS_2)) +
            charRow("!?~^|…") + listOf(deleteKey()),
        bottomRow("ABC", Layer.LETTERS, true),
    )

    private val SYMBOLS_2: List<List<Key>> = listOf(
        numberRow(),
        charRow("~`|•√π÷×<>"),
        charRow("£¢€¥^°={}\\"),
        listOf(Key("!#1", KeyType.SWITCH_LAYER, 1.5f, targetLayer = Layer.SYMBOLS)) +
            charRow("%©®™[]¶") + listOf(deleteKey()),
        bottomRow("ABC", Layer.LETTERS, true),
    )
}
